Name: Khushbu Shah
Project 2
DataBase Management 
Date:11-29-2020

How I approached the problem:

I started the project on 25th and started looking at the description of the project
I had my previous project1 opened and then going through how to create a table in SQL.
I had no issue with setting up server and creating tables actually. I did surf on internet for
how to create table in VISUAL STUDIO. ***I am Using Main.oo cpp.*** 
As you know have asked you questions about insert into statement ans shared my sources few times
as i was strugging and then I took your Idea of printing the Insertstatement before sending it to server.
that really did so much for me. then I figured It wasnt taking any values in. so I started editing and tried severeal stuff and finally found a way to
do it right way.

the platformI developed your code on- Visual Studio 2019
Sources:
https://www.w3schools.com/sql/sql_insert.asp
https://www.w3schools.com/sql/sql_count_avg_sum.asp


***How does my program work*****
-Sql server host is luredir.hopto.org:40306
then i put username, pw and databsse name
>>> a or l (press enter)
put typr then press enter
then add values and insert into should be working for all types.

**********Issues with my Project******
I think I have Issue with delete command 'd' and listing transcript.
 ERROR: You have an error in your SQL syntax; check the manual that corresponds to
         your MariaDB server version for the right syntax to use near '"' at line 1

User is able to quit the program when entered 'q'

I have another error with listing transcript, I am getting errors with sql statement that it doesnt ecognize certain column.
also to calculate GPA i have used HW-3 example. 

 However I do have some bugs with these commands. other than that my listing and adding works fine. 